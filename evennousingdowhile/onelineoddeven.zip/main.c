/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    
    int n;
    scanf("%d", &n);
    (n%2==0)?printf("even"):printf("0dd");
    return 0;
}
